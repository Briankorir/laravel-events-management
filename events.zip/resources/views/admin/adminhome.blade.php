@extends('admin.dashboard')

@section('main_container')
    <div class="right_col" role="main">
        @yield('content')
    </div>

  

@endsection
