<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="panel panel-body">
      <h1>Bookings</h1>
      <table class="table table-striped table-positive table-hover">

                <thead>
                <tr>
                    <th> Id.</th>
                    <th> Customer Name</th>
                    <th> Event Type</th>
                    <th> Event Date</th>
                    <th> Event Package</th>
                    <th> Approve Event</th>

                </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                              <td>
                                <?php echo e($booking->id); ?>

                              </td>
                              <td>
                                <?php echo e($booking->customer_name); ?>

                              </td>
                              <td>
                                <?php echo e($booking->event_type); ?>

                              </td>
                              <td>
                                <?php echo e($booking->event_date); ?>

                              </td>
                              <td>
                                <?php echo e($booking->event_package); ?>

                              </td>
                              <td>
                                <form class="success delete" action="/approve/<?php echo e($booking->id); ?>" method="post">
                                  <input type="hidden" name="_method" value="delete">
                                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                  <button class="btn btn-primary" type="submit" value="Approve">Approve</button>
                                </form>
                              </td>
                            </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </table>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>