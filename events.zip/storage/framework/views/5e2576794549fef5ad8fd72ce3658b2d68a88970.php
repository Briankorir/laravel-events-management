<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="panel panel-body">
      <h1>Approved Bookings</h1>
      <table class="table table-striped table-positive table-hover">

                <thead>
                <tr>
                    <th> Id.</th>
                    <th> Customer Name</th>
                    <th> Event Type</th>
                    <th> Event Date</th>
                    <th> Event Package</th>
                    <th> Approve Event</th>

                </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $approves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                              <td>
                                <?php echo e($approve->id); ?>

                              </td>
                              <td>
                                <?php echo e($approve->customer_name); ?>

                              </td>
                              <td>
                                <?php echo e($approve->event_type); ?>

                              </td>
                              <td>
                                <?php echo e($approve->event_date); ?>

                              </td>
                              <td>
                                <?php echo e($approve->event_package); ?>

                              </td>
                              <td>

                              </td>
                            </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </table>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>